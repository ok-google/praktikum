#include <iostream>

using namespace std;

void modul1()
{
   float uangsila;
   	float uangdidi;
   cout<<"Jumlah Uang Sila dan uang Didi adalah Rp 56.000 \n";
   cout<<"Uang Sila lebih banyak Rp 600 dari uang Didi \n";
   uangsila=(56000+600)/2;
   uangdidi=(56000-600)/2;
   cout<<"\nUang Sila = Rp "<<uangsila;
   cout<<endl;
   cout<<"Uang Didi = Rp "<<uangdidi;
   cout<<endl;
   cout<<"\nJadi uang Sila adalah Rp "<<uangsila;
   cout<<endl;
}
